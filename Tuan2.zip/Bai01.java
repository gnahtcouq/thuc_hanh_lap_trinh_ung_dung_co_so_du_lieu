
public class Bai01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HinhTron ht;
		ht = new HinhTron(10);
		System.out.println(ht);

		HinhChuNhat hcn;
		hcn = new HinhChuNhat(2, 5);
		System.out.println(hcn);
	}
}

class HinhTron {
	private double r;

	public HinhTron() {
	}

	public HinhTron(double r) {
		this.r = r;
	}

	public double getR() {
		return r;
	}

	public void setR(double r) {
		this.r = r;
	}

	public double tinhCV() {
		return 2 * Math.PI * r;
	}

	public double tinhDT() {
		return Math.PI * r * r;
	}

	public String toString() {
		return "HinhTron: r = " + r + "; CV = " + tinhCV() + "; DT = " + tinhDT();
	}
}

class HinhChuNhat {
	private double dai;
	private double rong;

	public HinhChuNhat() {

	}

	public HinhChuNhat(double dai, double rong) {
		this.dai = dai;
		this.rong = rong;
	}

	public double getDai() {
		return dai;
	}

	public void setDai(double dai) {
		this.dai = dai;
	}

	public double getRong() {
		return rong;
	}

	public void setRong(double rong) {
		this.rong = rong;
	}

	public double tinhCV() {
		return 2 * (dai + rong);
	}

	public double tinhDT() {
		return dai * rong;
	}

	public String toString() {
		return "HinhChuNhat: dai = " + dai + ", rong = " + rong + "; CV = " + tinhCV() + "; DT = " + tinhDT();
	}
}