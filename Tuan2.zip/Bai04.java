import java.util.*;
public class Bai04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Department> departments = new ArrayList<>();
		Department em1, em2, em3;
		em1 = new Department(1, "Ke toan");
		em1.addEmployee(new Employee(1, "H", 5000));
		em1.addEmployee(new Employee(2, "U", 7000));

		em2 = new Department(2, "Ky thuat");
		em2.addEmployee(new Employee(3, "O", 10000));
		em2.addEmployee(new Employee(4, "N", 12000));

		em3 = new Department(3, "Nhan su");
		em3.addEmployee(new Employee(5, "G", 6000));

		departments.add(em1);
		departments.add(em2);
		departments.add(em3);

		for (Department department : departments) {
			System.out.println("\n" + department);
			for (Employee e : department.getDsem())
				System.out.println(e);
		}
	}

}

class Department {

	private int id;
	private String name;

	public Department(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public Department() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Department other = (Department) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Department [id=" + id + ", name=" + name + "]";
	}

	private List<Employee> dsem = new ArrayList<>();

	public List<Employee> getDsem() {
		return dsem;
	}

	public void setDsem(List<Employee> dsem) {
		this.dsem = dsem;
	}

	public void addEmployee (Employee e) {
		dsem.add(e);
		e.setDepartment(this);
		
	}
}

class Employee {
	private int id;
	private String name;
	private double salary;
	private Department department;
	
	
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	public Employee(int id, String name, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	public Employee() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (id != other.id)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}
	
}
