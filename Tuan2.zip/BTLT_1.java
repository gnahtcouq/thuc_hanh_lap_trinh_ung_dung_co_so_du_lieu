import java.util.*;

public class BTLT_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Student> dssv = new ArrayList<>();
		dssv.add(new Student("Kha", "Ho", 89, 90, 95));
		System.out.println(dssv.get(0));
		System.out.println("\nDiem sau khi da cap nhat\n");
		dssv.set(0, new Student("Kha", "Ho", 93, 91, 86));
		System.out.println(dssv.get(0));
	}

}

class Student {
	private String firstname;
	private String lastname;
	private double exam1;
	private double exam2;
	private double exam3;

	public Student(String firstname, String lastname, double exam1, double exam2, double exam3) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.exam1 = exam1;
		this.exam2 = exam2;
		this.exam3 = exam3;
	}

	public Student() {
		super();
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public double getExam1() {
		return exam1;
	}

	public void setExam1(double exam1) {
		this.exam1 = exam1;
	}

	public double getExam2() {
		return exam2;
	}

	public void setExam2(double exam2) {
		this.exam2 = exam2;
	}

	public double getExam3() {
		return exam3;
	}

	public void setExam3(double exam3) {
		this.exam3 = exam3;
	}

	@Override
	public String toString() {
		return "Chao ban " + firstname + " " + lastname + ", Diem trung binh cua ban la: " + DiemTB();
	}

	public double DiemTB() {
		return (exam1 + exam2 + exam3) / 3;
	}
}