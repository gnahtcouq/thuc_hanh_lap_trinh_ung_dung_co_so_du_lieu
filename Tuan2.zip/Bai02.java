import java.util.ArrayList;
import java.util.List;

public class Bai02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<SinhVien> dssv = new ArrayList<>();
		dssv.add(new SinhVien("111", "Bach", 7));
		dssv.add(new SinhVien("222", "Kha", 7.5));
		dssv.add(new SinhVien("333", "Duc", 6.5));
		dssv.add(new SinhVien("444", "Nghia", 3));
		dssv.add(new SinhVien("555", "Tam", 9));
		for (int i = 0; i < dssv.size(); i++)
			System.out.println(dssv.get(i));
		double maxDtb = timDTBMax(dssv);
        System.out.println("Max dtb = " + maxDtb);
	}
	public static double timDTBMax ( List <SinhVien> dssv) {
		double max = 0 ; 
		for (SinhVien sv : dssv) {
			if (sv.getDtb()>max)
				max = sv.getDtb();
		}
		return max;
	}
}

class SinhVien {
	private String mssv;
	private String hoten;
	private double dtb;

	public SinhVien() {

	}

	public SinhVien(String mssv, String hoten, double dtb) {
		this.mssv = mssv;
		this.hoten = hoten;
		this.dtb = dtb;
	}

	public String getMssv() {
		return mssv;
	}

	public void setMssv(String mssv) {
		this.mssv = mssv;
	}

	public String getHoten() {
		return hoten;
	}

	public void setHoten(String hoten) {
		this.hoten = hoten;
	}

	public double getDtb() {
		return dtb;
	}

	public void setDtb(double dtb) {
		this.dtb = dtb;
	}

	public String toString() {
		return "SinhVien [mssv=" + mssv + ", hoten=" + hoten + ", dtb=" + dtb + "]";
	}

}