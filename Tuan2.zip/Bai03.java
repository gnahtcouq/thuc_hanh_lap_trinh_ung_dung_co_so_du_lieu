import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Bai03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<NhanVien> dsnv = new ArrayList<>();
		dsnv.add(new NhanVien("Bach", 1, 7));
		dsnv.add(new NhanVien("Kha", 2, 7.5));
		dsnv.add(new NhanVien("Duc", 3, 6.5));
		dsnv.add(new NhanVien("Nghia", 5, 3));
		dsnv.add(new NhanVien("Tam", 6, 9));
		for (int i = 0; i < dsnv.size(); i++)
			System.out.println(dsnv.get(i));
	}
}

class NhanVien {
	private String hoten;
	private int ngaycong;
	private double luongcb;
	
	public NhanVien() {

	}

	public NhanVien(String hoten, int ngaycong, double luongcb) {
		this.hoten = hoten;
		this.ngaycong = ngaycong;
		this.luongcb = luongcb;
	}

	public String getHoten() {
		return hoten;
	}
	public void setHoten(String hoten) {
		this.hoten = hoten;
	}
	public int getNgaycong() {
		return ngaycong;
	}
	public void setNgaycong(int ngaycong) {
		this.ngaycong = ngaycong;
	}
	public double getLuongcb() {
		return luongcb;
	}
	public void setLuongcb(double luongcb) {
		this.luongcb = luongcb;
	}
	
	public double getLuong() {
		return ngaycong * luongcb;
	}

	@Override
	public int hashCode() {
		return Objects.hash(hoten, luongcb, ngaycong);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NhanVien other = (NhanVien) obj;
		return Objects.equals(hoten, other.hoten)
				&& Double.doubleToLongBits(luongcb) == Double.doubleToLongBits(other.luongcb)
				&& ngaycong == other.ngaycong;
	}

	@Override
	public String toString() {
		return "NhanVien [hoten=" + hoten + ", ngaycong=" + ngaycong + ", luongcb=" + luongcb + ", luong=" + getLuong() + "]";
	}
}