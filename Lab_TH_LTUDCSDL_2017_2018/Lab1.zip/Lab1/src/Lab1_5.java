import java.text.SimpleDateFormat;
import java.util.*;
public class Lab1_5 {
    public static void main(String[] args) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date date;
        date = new Date(); //Lay ngay gio hien hanh
        System.out.println("Ngay hien tai: " + sdf.format(date));
    }
}

