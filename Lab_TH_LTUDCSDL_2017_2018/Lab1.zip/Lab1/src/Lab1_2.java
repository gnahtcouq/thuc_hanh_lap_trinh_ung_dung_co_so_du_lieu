import java.util.*;
public class Lab1_2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        float x, y, ketqua = 0;
        String c;
        System.out.print("x = ");
        x = input.nextFloat();
        System.out.print("y = ");
        y = input.nextFloat();
        input.nextLine(); //Xoa ky tu xuong dong
        System.out.print("Phep toan: ");
        c = input.nextLine();
        switch (c) {
            case "+":
                ketqua = x + y;
                break;
            case "-":
                ketqua = x - y;
                break;
        }
        System.out.println(x + " " + c + " " + y + " = " + ketqua);
    }
}
