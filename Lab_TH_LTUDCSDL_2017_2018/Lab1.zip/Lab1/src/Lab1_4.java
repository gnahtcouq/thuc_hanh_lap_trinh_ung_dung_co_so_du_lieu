public class Lab1_4 {
    public static void main(String[] args) {
        String s = "  dai hoc   cong     nghe sai  gon   ";
        System.out.println("Chieu dai: " + s.length());
        s = s.trim();
        System.out.println("Bỏ khoảng trắng trước và sau chuỗi: '" + s + "'");
        s = s.replaceAll(" +", " ");
        System.out.println("Bỏ khoảng trắng dư thừa: '" + s + "'");
    }    
}


