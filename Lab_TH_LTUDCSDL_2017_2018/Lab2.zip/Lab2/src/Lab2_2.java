import java.util.ArrayList;
import java.util.List;
public class Lab2_2 {
    public static void main(String[] args) {
        List<SinhVien> dssv = new ArrayList<>();
        dssv.add(new SinhVien("111", "Bach", 7));
        dssv.add(new SinhVien("222", "Kha", 7.5));
        dssv.add(new SinhVien("333", "Duc", 6.5));
        dssv.add(new SinhVien("444", "Nghia", 3));
        dssv.add(new SinhVien("555", "Tam", 9));
        for(int i = 0; i<dssv.size(); i++)
            System.out.println(dssv.get(i));
    }
}