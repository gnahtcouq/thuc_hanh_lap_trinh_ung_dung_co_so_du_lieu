public class Lab2_1 {
    public static void main(String[] args) {
        HinhTron ht;
        ht = new HinhTron(10);
        System.out.println(ht);
    }
}

