public class SinhVien {
    private String mssv;
    private String hoten;
    private double dtb;
    public SinhVien() {
    }
    public SinhVien(String mssv, String hoten, double dtb) {
        this.mssv = mssv;
        this.hoten = hoten;
        this.dtb = dtb;
    }
    public String getMssv() {
        return mssv;
    }
    public void setMssv(String mssv) {
        this.mssv = mssv;
    }
    public String getHoten() {
        return hoten;
    }
    public void setHoten(String hoten) {
        this.hoten = hoten;
    }
    public double getDtb() {
        return dtb;
    }
    public void setDtb(double dtb) {
        this.dtb = dtb;
    }
    @Override
    public String toString() {
        return "SinhVien{" + "mssv=" + mssv + 
                ", hoten=" + hoten + ", dtb=" + dtb + '}';
    }
}
