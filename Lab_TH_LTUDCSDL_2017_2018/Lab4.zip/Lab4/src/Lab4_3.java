import java.sql.*;
public class Lab4_3 {
    public static void main(String[] args) {
        // TODO code application logic here
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/labjdbc", "root", "");
            Statement stmt = con.createStatement();
            String sql = "select code, name, population from country limit 0,10";
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                System.out.println(rs.getString("code") + " - " 
                        + rs.getString("name") + " - " + rs.getDouble("population"));
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
