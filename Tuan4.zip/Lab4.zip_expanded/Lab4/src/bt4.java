public class bt4 {
	public static void main(String[] args) {

	}
}
