import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class bt1 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		try (BufferedWriter br = new BufferedWriter(new FileWriter("data1.txt", true))) {
			System.out.print("Nhập Họ tên: ");
			String hoTen = input.nextLine();
			System.out.print("Nhập Lớp: ");
			String lop = input.nextLine();

			br.write(hoTen + " " + lop);
			br.newLine();
			System.out.println("Đã nối nội dung vào file!");
		} catch (IOException ex) {
			Logger.getLogger(Lab4_1.class.getName()).log(Level.SEVERE, null, ex);
		}
	}
}
