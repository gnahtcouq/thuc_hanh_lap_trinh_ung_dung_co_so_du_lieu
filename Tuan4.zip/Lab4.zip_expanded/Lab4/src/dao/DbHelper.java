package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DbHelper {
	private static Connection con = null;

	public static Connection getConnection() {
		if (con == null) {
			// Doc file cau hinh properties
			ResourceBundle bundle = ResourceBundle.getBundle("db");
			String url = bundle.getString("url");
			String user = bundle.getString("user");
			String pwd = bundle.getString("pwd");
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				con = DriverManager.getConnection(url, user, pwd);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return con;
	}

	public static void close() {
		if (con != null) {
			try {
				con.close();
			} catch (SQLException ex) {
				Logger.getLogger(DbHelper.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
	}

	public boolean checkLoginCredentials(String firstName, String lastName, String password) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			String sql = "SELECT * FROM authentication WHERE FName = ? AND LName = ? AND Password = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, firstName);
			stmt.setString(2, lastName);
			stmt.setString(3, password);
			rs = stmt.executeQuery();

			return rs.next(); // If there is a row in the result set, login is successful
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			// Close the resources
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}