/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import domain.City;

/**
 *
 * @author Duc Le
 */
public class CityDAO {
	private final Connection con;

	public CityDAO() {
		con = DbHelper.getConnection();
	}

	public List<City> findAll(int rows) {
		List<City> result = null;
		try {
			PreparedStatement pstmt = con.prepareStatement("select * from city limit 0, " + rows);
			ResultSet rs = pstmt.executeQuery();
			if (rs.isBeforeFirst()) {
				result = new ArrayList<>();
				while (rs.next()) {
					City city = City.fromResult(rs);
					result.add(city);
				}
			}
		} catch (SQLException ex) {
			Logger.getLogger(CityDAO.class.getName()).log(Level.SEVERE, null, ex);
		}
		return result;
	}

	public void addCity(City city) {
		try {
			String sql = "INSERT INTO city (name, countryCode, district, population) VALUES (?, ?, ?, ?)";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, city.getName());
			pstmt.setString(2, city.getCountryCode());
			pstmt.setString(3, city.getDistrict());
			pstmt.setInt(4, city.getPopulation());
			pstmt.executeUpdate();
		} catch (SQLException ex) {
			Logger.getLogger(CityDAO.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	public List<City> findByCountryCode(String countryCode) {
		List<City> result = new ArrayList<>();
		try {
			String sql = "SELECT * FROM city WHERE countryCode = ?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, countryCode);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				City city = City.fromResult(rs);
				result.add(city);
			}
		} catch (SQLException ex) {
			Logger.getLogger(CityDAO.class.getName()).log(Level.SEVERE, null, ex);
		}
		return result;
	}

	public void save(City city) {
		try {
			// Kiểm tra xem thành phố đã tồn tại hay chưa
			PreparedStatement checkStmt = con.prepareStatement("SELECT * FROM city WHERE id = ?");
			checkStmt.setInt(1, city.getId());
			ResultSet checkResult = checkStmt.executeQuery();
			if (checkResult.next()) {
				System.out.println("Thành phố đã tồn tại trong cơ sở dữ liệu.");
				return; // Bỏ qua việc thêm thành phố
			}

			// Thêm thành phố vào cơ sở dữ liệu
			PreparedStatement insertStmt = con.prepareStatement(
					"INSERT INTO city (id, name, countryCode, district, population) VALUES (?, ?, ?, ?, ?)");
			insertStmt.setInt(1, city.getId());
			insertStmt.setString(2, city.getName());
			insertStmt.setString(3, city.getCountryCode());
			insertStmt.setString(4, city.getDistrict());
			insertStmt.setInt(5, city.getPopulation());
			insertStmt.executeUpdate();

			System.out.println("Thêm thành phố thành công.");
		} catch (SQLException ex) {
			Logger.getLogger(CityDAO.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	public void delete(int id) {
		try {
			String sql = "DELETE FROM city WHERE id = ?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, id);
			pstmt.executeUpdate();
		} catch (SQLException ex) {
			Logger.getLogger(CityDAO.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

}
