import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import dao.DbHelper;

public class baitaplamthem extends JFrame {

	private JPanel contentPane;
	private JTextField txtLName;
	private JTextField txtFName;
	private JTextField txtPassword;
	private DbHelper dbHelper;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					baitaplamthem frame = new baitaplamthem();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public baitaplamthem() {
		dbHelper = new DbHelper();

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 625, 346);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		// Load the image
		URL urlImg = baitaplamthem.class.getResource("lock.png");
		Image originalImage = Toolkit.getDefaultToolkit().createImage(urlImg);

		// Resize the image
		int desiredWidth = getWidth() / 2; // half the width of the window
		int desiredHeight = getHeight(); // full height of the window
		Image resizedImage = originalImage.getScaledInstance(desiredWidth, desiredHeight, Image.SCALE_SMOOTH);

		// Create a ImageIcon with the resized image
		ImageIcon icon = new ImageIcon(resizedImage);

		// Create a JLabel to display the image
		JLabel imageLabel = new JLabel(icon);
		imageLabel.setBounds(10, 10, 241, 289);
		imageLabel.setPreferredSize(new Dimension(desiredWidth, desiredHeight));

		// Add the image label to the content pane
		contentPane.add(imageLabel);

		JLabel lblFName = new JLabel("First Name:");
		lblFName.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblFName.setBounds(283, 45, 88, 20);
		contentPane.add(lblFName);

		JLabel lblLName = new JLabel("Last Name:");
		lblLName.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblLName.setBounds(283, 85, 88, 20);
		contentPane.add(lblLName);

		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblPassword.setBounds(283, 127, 88, 20);
		contentPane.add(lblPassword);

		txtLName = new JTextField();
		txtLName.setBounds(381, 79, 194, 26);
		contentPane.add(txtLName);
		txtLName.setColumns(10);

		txtFName = new JTextField();
		txtFName.setColumns(10);
		txtFName.setBounds(381, 39, 194, 26);
		contentPane.add(txtFName);

		txtPassword = new JPasswordField();
		txtPassword.setColumns(10);
		txtPassword.setBounds(381, 121, 194, 26);
		contentPane.add(txtPassword);

		JButton btnLogin = new JButton("Login");
		btnLogin.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnLogin.setBounds(416, 172, 130, 39);
		contentPane.add(btnLogin);

		// ActionListener for btnLogin
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String firstName = txtFName.getText();
				String lastName = txtLName.getText();
				String password = txtPassword.getText();

				// Check login credentials against the database
				boolean loginSuccessful = dbHelper.checkLoginCredentials(firstName, lastName, password);
				if (loginSuccessful) {
					// Đăng nhập thành công, hiển thị GUI chức năng
					showFunctionalityGUI();
				} else {
					JOptionPane.showMessageDialog(baitaplamthem.this, "Invalid login credentials. Please try again.");
				}
			}
		});

	}

	public void showFunctionalityGUI() {
		// Tạo JFrame cho giao diện chức năng
		JFrame functionalityFrame = new JFrame("Functionality");
		functionalityFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		functionalityFrame.setSize(400, 300);

		// Tạo JPanel và thêm các thành phần vào
		JPanel functionalityPanel = new JPanel();
		functionalityPanel.setLayout(new FlowLayout());

		JButton btnFunction1 = new JButton("Function 1");
		JButton btnFunction2 = new JButton("Function 2");

		functionalityPanel.add(btnFunction1);
		functionalityPanel.add(btnFunction2);

		functionalityFrame.add(functionalityPanel);
		functionalityFrame.setVisible(true);
	}

}
