import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Lab4_3 {
	public static void main(String[] args) {
		// TODO code application logic here
		Connection con = null;
		try {
			// Kết nối đến CSDL
//			Class.forName("com.mysql.jdbc.Driver"); -> OLD Version
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/labjdbc", "root", "");

//			Statement stmt = con.createStatement();
//			String sql = "select code, name, population from country limit 0,10";
//			ResultSet rs = stmt.executeQuery(sql);

			// Truy vấn các nước có tên bắt đầu bằng chữ A
			String sql = "SELECT code, name, population FROM country WHERE name LIKE 'A%'";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			// In kết quả truy vấn
			while (rs.next()) {
				System.out.println(
						rs.getString("code") + " - " + rs.getString("name") + " - " + rs.getDouble("population"));
			}

			// Đóng kết nối
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
