import java.util.List;

import dao.CityDAO;
import dao.DbHelper;
import domain.City;

public class bt6 {
	public static void main(String[] args) {
		// Kết nối cơ sở dữ liệu
		DbHelper.getConnection();

		// Tạo đối tượng CityDAO
		CityDAO cityDao = new CityDAO();

		// Thêm 3 đối tượng City mới
		City city1 = new City(4082, "Bich Van", "VNM", "VN", 1000);
		City city2 = new City(4083, "Be May", "VNM", "VN", 2000);
		City city3 = new City(4084, "May Be", "VNM", "VN", 3000);

		// Lưu các đối tượng City vào cơ sở dữ liệu
		cityDao.save(city1);
		cityDao.save(city2);
		cityDao.save(city3);

		// Hiển thị danh sách các đối tượng vừa tạo
		List<City> cities = cityDao.findByCountryCode("VNM");
		System.out.println("Danh sách các đối tượng City vừa tạo:");
		for (City city : cities) {
			System.out.println(city);
		}

		// Xóa các đối tượng City
		cityDao.delete(city1.getId());
		cityDao.delete(city2.getId());
		cityDao.delete(city3.getId());

		// Đóng kết nối cơ sở dữ liệu
		DbHelper.close();
	}
}
