import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class bt3 {
	public static void main(String[] args) {
		Connection con = null;
		try {
			// Kết nối đến cơ sở dữ liệu
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/labjdbc", "root", "");

			// Truy vấn các thành phố có dân số nhỏ hơn 100,000
			String sql = "SELECT name, district, population FROM city WHERE population < 100000 LIMIT 20";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			// In kết quả truy vấn
			while (rs.next()) {
				System.out.println(
						rs.getString("name") + " - " + rs.getString("district") + " - " + rs.getInt("population"));
			}

			// Đóng kết nối
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
