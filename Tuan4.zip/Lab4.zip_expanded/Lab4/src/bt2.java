import java.util.ResourceBundle;

public class bt2 {
	public static void main(String[] args) {
		// TODO code application logic here
		ResourceBundle bundle = ResourceBundle.getBundle("prop2");
		bundle.keySet();
		for (String key : bundle.keySet())
			System.out.println("key = " + key + ", value = " + bundle.getString(key));
	}
}
