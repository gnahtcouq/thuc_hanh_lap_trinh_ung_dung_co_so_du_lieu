import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import dao.DbHelper;
import domain.City;

public class bt5 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Nhập district: ");
		String district = input.nextLine();

		try {
			String sql = "SELECT * FROM city WHERE district = ?";
			PreparedStatement pstmt = DbHelper.getConnection().prepareStatement(sql);
			pstmt.setString(1, district);
			ResultSet rs = pstmt.executeQuery();

			if (rs.isBeforeFirst()) {
				while (rs.next()) {
					City city = City.fromResult(rs);
					System.out.println(city);
				}
			} else {
				System.out.println("Không tìm thấy thành phố nào có quận " + district);
			}
		} catch (SQLException ex) {
			Logger.getLogger(bt5.class.getName()).log(Level.SEVERE, null, ex);
		} finally {
			DbHelper.close();
		}
	}
}
