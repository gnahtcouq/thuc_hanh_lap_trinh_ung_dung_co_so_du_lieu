import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Lab4_1 {
	public static void main(String[] args) {
		// TODO code application logic here
		Scanner input = new Scanner(System.in);

		try (BufferedWriter br = new BufferedWriter(new FileWriter("data1.txt"))) {
			System.out.println("Nhap noi dung file: ");
			String content = input.nextLine();
			br.write(content);
			System.out.println("Done!");
		} catch (IOException ex) {
			Logger.getLogger(Lab4_1.class.getName()).log(Level.SEVERE, null, ex);
		}

		// Doc noi dung file vua tao
		try (BufferedReader br = new BufferedReader(new FileReader("data1.txt"))) {
			String line;
			System.out.println("Noi dung file:");
			while ((line = br.readLine()) != null) {
				System.out.println(line);
			}
		} catch (IOException ex) {
			Logger.getLogger(Lab4_1.class.getName()).log(Level.SEVERE, null, ex);
		}
	}
}
