
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import dao.CityDAO;
import dao.DbHelper;

public class Lab4_4 {
	public static void main(String[] args) {
		// Get CityDAO object
		CityDAO cityDAO = new CityDAO();

		// Insert new city
//		City newCity = new City();
//		newCity.setName("LT CSDL");
//		newCity.setCountryCode("VNM");
//		newCity.setDistrict("VN");
//		newCity.setPopulation(1000);

//		if (cityDAO.insert(newCity))
//			System.out.println("New city inserted successfully.");
//		else
//			System.out.println("Failed to insert new city.");
		//

		Scanner input = new Scanner(System.in);
		System.out.println("Nhap countrycode: ");
		String code = input.nextLine();
		try {
			//
			//
			String selectSql = "select * from city where countrycode = ?";
			PreparedStatement pstmt = DbHelper.getConnection().prepareStatement(selectSql);
			pstmt.setString(1, code);
			ResultSet rs = pstmt.executeQuery();
			if (rs.isBeforeFirst()) {
				while (rs.next()) {
					System.out.printf("Id=%d; Name=%s; CountryCode=%s; District=%s; Population=%d;\n", rs.getInt(1),
							rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5));
				}
			} else {
				System.out.println("Khong tim thay!");
			}
		} catch (SQLException ex) {
			Logger.getLogger(Lab4_4.class.getName()).log(Level.SEVERE, null, ex);
		} finally {
			DbHelper.close();
		}
	}
}
