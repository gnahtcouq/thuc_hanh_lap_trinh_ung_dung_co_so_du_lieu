
import java.util.List;

import dao.CityDAO;
import dao.DbHelper;
import domain.City;

public class Lab4_6 {
	public static void main(String[] args) {
		// TODO code application logic here
		CityDAO cityDao = new CityDAO();
//        List<City> cities = cityDao.find(10); // Lay 10 ket qua
		List<City> cities = cityDao.findByCountryCode("VNM");
		for (City city : cities)
			System.out.println(city);
		DbHelper.close();
	}
}
