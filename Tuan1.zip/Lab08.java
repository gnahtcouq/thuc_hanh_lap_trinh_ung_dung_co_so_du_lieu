import java.util.Scanner;

public class Lab08 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		int c;
		System.out.print("Nhap thang: ");
		c = input.nextInt();
		switch (c) {
		case 1:
		case 2:
		case 3:
			System.out.print("Quy 1");
			break;
		case 4:
		case 5:
		case 6:
			System.out.print("Quy 2");
			break;
		case 7:
		case 8:
		case 9:
			System.out.print("Quy 3");
			break;
		case 10:
		case 11:
		case 12:
			System.out.print("Quy 4");
			break;
		default:
			System.out.print("Nhap thang tu 1-12");
			break;
		}
	}
}
