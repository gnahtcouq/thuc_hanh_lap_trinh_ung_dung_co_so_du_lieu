
public class Lab01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 10;
		Fibonaci(n);
	}
	public static void Fibonaci(int n) {
		int f1 = 1;
		int f2 = 1;
		System.out.print(f1 + "\t" + f2);
		int f;
		for (int i = 3; i <= n; i++) {
			f = f1 + f2;
			f1 = f2;
			f2 = f;
			System.out.print("\t" + f);
		}
	}

}