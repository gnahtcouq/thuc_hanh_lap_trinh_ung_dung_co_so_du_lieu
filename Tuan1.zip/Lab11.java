import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Lab11 {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		String dateInString, datetam;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		System.out.print("Nhap ngay/thang/nam: ");
		dateInString = input.nextLine();
		Date date = sdf.parse(dateInString);
		
		// lấy ngày giờ hiện hành
		datetam = sdf.format(new Date());
		Date date2 = sdf.parse(datetam);
		
		int check = date.compareTo(date2);
		if (check == 0)
			System.out.println("\n2 ngay giong nhau");
		else if (check > 0)
			System.out.println("\nNgay da nhap sau ngay hien tai");
		else
			System.out.println("\nNgay da nhap truoc ngay hien tai");
	}

}
