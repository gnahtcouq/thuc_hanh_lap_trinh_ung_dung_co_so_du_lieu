import java.util.Scanner;
  
public class Lab13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		int a;
		System.out.print("\nNhap so nguyen: ");
		a = input.nextInt();
		if (a % 3 == 0 && a % 5 == 0)
			System.out.print(a + " la boi so cua 3 va 5");
		else
			System.out.print(a + " khong phai boi so cua 3 va 5");
	}

}
