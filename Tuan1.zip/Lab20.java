import java.util.ArrayList;
public class Lab20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> list1 = new ArrayList<Integer>();
		ArrayList<Integer> list2 = new ArrayList<Integer>();
		list1.add(5);
		list1.add(2);
		list1.add(3);
		list1.add(4);
		list2.add(5);
		list2.add(2);
		list2.add(3);
		list2.add(4);
		// hiển thị các phần tử của list
		System.out.println("Các phần tử có trong list1 là: ");
		System.out.println(list1);
		System.out.println("Các phần tử có trong list2 là: ");
		System.out.println(list2);
		
		boolean result = list1.equals(list2);
		System.out.print(result);
	}

}
