import java.util.*;
public class BTVN01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		double gio, luong, sotien = 0;
		System.out.print("\nNhap gio lam viec: ");
		gio = input.nextDouble();
		System.out.print("\nNhap luong: ");
		luong = input.nextDouble();
		if (gio < 40)
			sotien = luong * gio;
		else if (gio >= 40)
			sotien = 40 * luong * 1.5 + ((gio - 40) * luong);
		System.out.print("\nSo tien = " + sotien);
	}

}
