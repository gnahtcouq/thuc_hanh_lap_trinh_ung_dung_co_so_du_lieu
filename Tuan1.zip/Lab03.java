import java.util.*;

public class Lab03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		float x, y, ketqua = 0;
		int check = 1;
		String c;
		System.out.print("x = ");
		x = input.nextFloat();
		System.out.print("y = ");
		y = input.nextFloat();
		input.nextLine(); // Xoa ky tu xuong dong
		System.out.print("Phep toan: ");
		c = input.nextLine();
		switch (c) {
		case "+":
			ketqua = x + y;
			break;
		case "-":
			ketqua = x - y;
			break;
		case "*":
			ketqua = x * y;
			break;
		case "/":
			ketqua = x / y;
			break;
		default:
//			System.out.print("Nhap sai phep toan");
			check = 0;
			break;
		}
		if (y == 0 || c == "/")
			System.out.print("Khong the thuc hien phep chia cho 0");
		else if (check == 0)
			System.out.print("Nhap sai phep toan");
		else
			System.out.println(x + " " + c + " " + y + " = " + ketqua);
	}

}
