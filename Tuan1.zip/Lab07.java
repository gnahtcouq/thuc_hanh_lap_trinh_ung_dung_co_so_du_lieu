import java.util.Scanner;

public class Lab07 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		int a, b, c;
		System.out.print("Nhap so nguyen a: ");
		a = input.nextInt();
		System.out.print("Nhap so nguyen b: ");
		b = input.nextInt();
		System.out.print("Nhap so nguyen c: ");
		c = input.nextInt();
		if (a >= b && a >= c)
	         System.out.println( a + " la so lon nhat.");
	      else if (b >= a && b >= c)
	         System.out.println( b + " la so lon nhat.");
	      else
	         System.out.println( c + " la so lon nhat.");
	}

}
