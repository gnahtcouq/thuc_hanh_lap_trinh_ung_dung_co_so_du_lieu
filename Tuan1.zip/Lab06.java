import java.text.SimpleDateFormat;
import java.util.*;

public class Lab06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date date;
		date = new Date(); // Lay ngan gio hien hanh
		System.out.println("Ngay hien tai: " + sdf.format(date));
		
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy/MM/dd");
		Date date1;
		date1 = new Date(); // Lay ngan gio hien hanh
		System.out.println("Ngay hien tai: " + sdf1.format(date1));
	}
}
