import java.util.Scanner;
public class Lab16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		String s;
		System.out.print("\nNhap chuoi: ");
		s = input.nextLine();
		s = s.trim();
		char[] array = s.toCharArray();
		for (int i = array.length - 1; i >= 0; i--)
			System.out.print(array[i]);
	}

}
