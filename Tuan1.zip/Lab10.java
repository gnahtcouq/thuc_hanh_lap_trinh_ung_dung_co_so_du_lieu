import java.util.Scanner;

public class Lab10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		String s, ho="", ten="";
		System.out.print("Nhap ho ten: ");
		s = input.nextLine();
//		System.out.print("\nHo ten: " + s);
		s = s.trim();
		char[] array = s.toCharArray();
		int idx = 0;
		for (int i = array.length - 1; i >= 0; i--) {
			if (array[i] == ' ') {
				idx = i + 2;
				break;
			}
		}
//		System.out.print("idx = " + idx);
		for (int i = 0; i < idx - 2; i++)
			ho += array[i];
		System.out.print("\nHo: " + ho);
		for (int i = idx - 1; i < array.length; i++)
			ten += array[i];
		System.out.print("\nTen: " + ten);
	}
}

// char[] array = s.toLowerCase().toCharArray();
// array[0] = Character.toUpperCase(array[0]);
// for (int i = 1; i < array.length; i++)
//	if (Character.isWhitespace(array[i - 1]))
//		array[i] = Character.toUpperCase(array[i]);
// return new String(array);