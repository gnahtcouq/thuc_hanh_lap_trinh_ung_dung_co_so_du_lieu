import java.util.Scanner;

public class Lab14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		int a;
		System.out.print("\nNhap so nguyen duong: ");
		a = input.nextInt();
		int flag = 0;
		for (int i = 1; i <= a; i++)
			if (i * i == a) {
				flag = 1;
				break;
			}
		if (flag == 1)
			System.out.print(a + " la so chinh phuong");
		else
			System.out.print(a + " khong phai so chinh phuong");
	}
}
