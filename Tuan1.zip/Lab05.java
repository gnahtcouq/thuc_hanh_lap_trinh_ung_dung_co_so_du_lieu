public class Lab05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "   dai hoc   cong      nghe sai  gon   ";
		System.out.println("Chieu dai: " + s.length());
		s = s.trim();
		System.out.println("Bo khoang trang truoc va sau chuoi: '" + s + "'");
		s = s.replaceAll(" +", " ");
		System.out.println("Bo khoang trang du thua: '" + s + "'");

		s = vietHoaDauMoiTu(s);
		System.out.println("Viet hoa dau moi tu: '" + s + "'");
	}
	
	public static String vietHoaDauMoiTu(String s) {
		char[] array = s.toLowerCase().toCharArray();
		array[0] = Character.toUpperCase(array[0]);
		for (int i = 1; i < array.length; i++)
			if (Character.isWhitespace(array[i - 1]))
				array[i] = Character.toUpperCase(array[i]);
		return new String(array);
	}
}
