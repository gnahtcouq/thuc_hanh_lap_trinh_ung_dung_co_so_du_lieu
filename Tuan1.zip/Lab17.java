import java.util.Scanner;
public class Lab17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		String s;
		int demKhoangTrang = 0, demKiTuChuCai = 0, demKiTuSo = 0;
		System.out.print("\nNhap chuoi: ");
		s = input.nextLine();
		char[] array = s.toCharArray();
		for (int i = 0; i < array.length; i++) {
			if (array[i] == ' ')
				demKhoangTrang++;
			else if (array[i] >= 65 && array[i] <= 90) // A -> Z
				demKiTuChuCai++;
			else if (array[i] >= 97 && array[i] <= 122) // a -> z
				demKiTuChuCai++;
			else if (array[i] >= 48 || array[i] <= 57) // 0 -> 9
				demKiTuSo++;
		}
		System.out.print("\nSo ki tu chu cai = " + demKiTuChuCai);
		System.out.print("\nSo ki tu so = " + demKiTuSo);
		System.out.print("\nSo ki tu khoang trang = " + demKhoangTrang);
	}

}
