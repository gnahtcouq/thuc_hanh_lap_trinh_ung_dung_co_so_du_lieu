import java.util.*;

public class Lab09 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		int a[], n;
		System.out.print("Nhap so phan tu: ");
		n = input.nextInt();
		a = new int[n];

		NhapMang(a);
		XuatMang(a);
		SapXepMang(a, n);
		System.out.print("\nPhan tu lon nhat trong mang la: " + a[0]);
	}

	public static void NhapMang(int a[]) {
		Scanner input = new Scanner(System.in);
		for (int i = 0; i < a.length; i++) {
			System.out.print("a[" + i + "] = ");
			a[i] = input.nextInt();
		}
	}

	public static void XuatMang(int a[]) {
		for (int i = 0; i < a.length; i++)
			System.out.print("\t" + a[i]);
	}

	public static void SapXepMang(int a[], int n) {
		for (int i = 0; i < n - 1; i++) {
			for (int j = i + 1; j < n; j++) {
				if (a[i] < a[j]) {
					int tam = a[i];
					a[i] = a[j];
					a[j] = tam;
				}
			}
		}
	}
}
