import java.util.Scanner;

public class Lab12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		float toan, ly, hoa, dtb;
		System.out.print("\nNhap diem toan: ");
		toan = input.nextFloat();
		System.out.print("\nNhap diem ly: ");
		ly = input.nextFloat();
		System.out.print("\nNhap diem hoa: ");
		hoa = input.nextFloat();
		dtb = (toan + ly + hoa) / 3;
		if (dtb < 5)
			System.out.print("\nRot!");
		else if (dtb >= 5)
			System.out.print("\nDau!");
		if (dtb >= 5 && dtb < 7)
			System.out.print("\nTrung Binh!");
		else if (dtb >= 7 && dtb < 8)
			System.out.print("\nKha!");
		else if (dtb >= 8 && dtb < 9)
			System.out.print("\nGioi!");
		else
			System.out.print("\nXuat sac!");
	}

}
