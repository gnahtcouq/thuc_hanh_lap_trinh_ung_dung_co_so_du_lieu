import java.util.ArrayList;
import java.util.Collections;
public class Lab19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(5);
		list.add(2);
		list.add(3);
		list.add(4);
		// hiển thị các phần tử của list
		System.out.println("Các phần tử có trong list là: ");
		System.out.println(list);
		Collections.sort(list);
		System.out.println("Sắp xếp list: ");
		for (int i = 0; i < list.size(); i++)
			System.out.print(list.get(i) + " ");
	}

}
