import java.util.ArrayList;

public class Lab18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> listString = new ArrayList<String>();
		listString.add("Java");
		listString.add("C++");
		listString.add("PHP");
		listString.add("Java");
		// hiển thị các phần tử của list
		System.out.println("Các phần tử có trong list là: ");
		System.out.println(listString);
		System.out.println("Đảo ngược list: ");
		for (int i = listString.size() - 1; i >= 0; i--)
			System.out.print(listString.get(i) + " ");
	}

}
