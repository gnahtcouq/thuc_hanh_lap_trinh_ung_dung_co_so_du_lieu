package controller;

import java.util.List;

import org.hibernate.Session;

import model.Nhanvien;
import util.HibernateUtil;

public class NhanvienService {
	public List<Nhanvien> getNhanviens() {
		Session ses = HibernateUtil.openSession();
		ses.beginTransaction();
		List<Nhanvien> listNhanviens = ses.createQuery("from Nhanvien").list();
		ses.getTransaction().commit();
		ses.close();
		return listNhanviens;
	}

	public Nhanvien get(int id) {
		Session ses = HibernateUtil.openSession();
		ses.beginTransaction();
		Nhanvien c = (Nhanvien) ses.get(Nhanvien.class, id);
		ses.getTransaction().commit();
		ses.close();
		return c;
	}

	public void create(Nhanvien obj) {
		Session ses = HibernateUtil.openSession();
		ses.beginTransaction();
		ses.save(obj);
		ses.getTransaction().commit();
		ses.close();
	}

	public void save(Nhanvien obj) {
		Session ses = HibernateUtil.openSession();
		ses.beginTransaction();
		ses.update(obj);
		ses.getTransaction().commit();
		ses.close();
	}

	public void delete(Nhanvien obj) {
		Session ses = HibernateUtil.openSession();
		ses.beginTransaction();
		ses.delete(obj);
		ses.getTransaction().commit();
		ses.close();
	}
}
