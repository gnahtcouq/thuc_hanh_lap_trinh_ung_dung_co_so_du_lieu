package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Nhanvien;

/**
 * Servlet implementation class AddNhanvien
 */
@WebServlet("/AddNhanvien")
public class AddNhanvien extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final NhanvienService es = new NhanvienService();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddNhanvien() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String hesoluongString = request.getParameter("hesoluong");
		float hsl = 0.0f;
		try {
			hsl = Float.parseFloat(hesoluongString);
			Nhanvien e = new Nhanvien(request.getParameter("ten"), request.getParameter("ngaysinh"), hsl);
			es.create(e);
			response.sendRedirect("Controller");
		} catch (NumberFormatException e) {
			request.setAttribute("error", "Hesoluong khong hop le. Xin hay nhap lai");
			request.getRequestDispatcher("/WEB-INF/view/AddNhanvienForm.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
