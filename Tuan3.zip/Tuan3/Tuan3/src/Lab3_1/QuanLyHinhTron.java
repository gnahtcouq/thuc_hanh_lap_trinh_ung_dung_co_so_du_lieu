package Lab3_1;

import java.util.ArrayList;

public class QuanLyHinhTron {
	private ArrayList<HinhTron> ds = new ArrayList<HinhTron>();

	public ArrayList<HinhTron> getDs() {
		return ds;
	}

	public void setDs(ArrayList<HinhTron> ds) {
		this.ds = ds;
	}

	public void themHinhTron(HinhTron hinhTron) {
		ds.add(hinhTron);
	}

	public void xoaHinhTron(int index) {
		if (index >= 0 && index < ds.size())
			ds.remove(index);
	}

	public QuanLyHinhTron(ArrayList<HinhTron> ds) {
//		super();
		this.ds = ds;
	}

	public QuanLyHinhTron() {
//		super();
		// TODO Auto-generated constructor stub
	}
}
