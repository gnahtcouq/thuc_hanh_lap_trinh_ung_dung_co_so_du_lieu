package Lab3_1;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class bt1 extends JFrame {

	private JPanel contentPane;
	private JTextField txtA;
	private JTextField txtB;
	private JTextField txtKq;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;
	private JButton btnNewButton_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					bt1 frame = new bt1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public bt1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 200);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("So A:");
		lblNewLabel.setBounds(34, 25, 46, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("So B:");
		lblNewLabel_1.setBounds(34, 50, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Ket qua:");
		lblNewLabel_2.setBounds(34, 75, 46, 14);
		contentPane.add(lblNewLabel_2);
		
		txtA = new JTextField();
		txtA.setBounds(88, 25, 295, 20);
		contentPane.add(txtA);
		txtA.setColumns(10);
		
		txtB = new JTextField();
		txtB.setColumns(10);
		txtB.setBounds(88, 50, 295, 20);
		contentPane.add(txtB);
		
		txtKq = new JTextField();
		txtKq.setColumns(10);
		txtKq.setBounds(88, 75, 295, 20);
		contentPane.add(txtKq);
		
		JButton btnNewButton = new JButton("+");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
		        double a = Double.parseDouble(txtA.getText());
		        double b = Double.parseDouble(txtB.getText());
		        double kq = a + b;
		        txtKq.setText(kq + "");
			}
		});
		btnNewButton.setBounds(88, 106, 53, 23);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("-");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        double a = Double.parseDouble(txtA.getText());
		        double b = Double.parseDouble(txtB.getText());
		        double kq = a - b;
		        txtKq.setText(kq + "");
			}
		});
		btnNewButton_1.setBounds(151, 106, 53, 23);
		contentPane.add(btnNewButton_1);
		
		btnNewButton_2 = new JButton("*");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        double a = Double.parseDouble(txtA.getText());
		        double b = Double.parseDouble(txtB.getText());
		        double kq = a * b;
		        txtKq.setText(kq + "");
			}
		});
		btnNewButton_2.setBounds(214, 106, 53, 23);
		contentPane.add(btnNewButton_2);
		
		btnNewButton_3 = new JButton("/");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        double a = Double.parseDouble(txtA.getText());
		        double b = Double.parseDouble(txtB.getText());
		        double kq = a / b;
		        txtKq.setText(kq + "");
			}
		});
		btnNewButton_3.setBounds(277, 106, 53, 23);
		contentPane.add(btnNewButton_3);
	}
}
