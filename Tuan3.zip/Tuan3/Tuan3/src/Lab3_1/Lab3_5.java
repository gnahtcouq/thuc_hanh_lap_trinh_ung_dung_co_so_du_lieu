package Lab3_1;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class Lab3_5 extends JFrame {
	private static final int FRAME_WIDTH = 600;
	private static final int FRAME_HEIGHT = 400;
	private static final int BUTTON_WIDTH = 100;
	private static final int BUTTON_HEIGHT = 33;
	private static final int LABEL_WIDTH = 50;
	private static final int TEXTFIELD_WIDTH = 400;
	private static final int ROW_HEIGHT = 25;
	//
	private JPanel contentPane;
	private JTextField txtR;
	private JTable table;
	private QuanLyHinhTron ql;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Lab3_5 frame = new Lab3_5();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Lab3_5() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblR = new JLabel("R = ");
		lblR.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblR.setBounds(27, 24, 79, 24);
		contentPane.add(lblR);

		txtR = new JTextField();
		txtR.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtR.setBounds(73, 24, 484, 24);
		contentPane.add(txtR);
		txtR.setColumns(10);

		ql = new QuanLyHinhTron();
		ArrayList<HinhTron> ds = ql.getDs();

		JButton btnThem = new JButton("Them");
		btnThem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String r = txtR.getText().trim();
				double R = 0;
				if (r.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Ban can nhap R");
					return;
				}
				try {
					R = Double.parseDouble(r);
				} catch (NumberFormatException ex) {
					JOptionPane.showMessageDialog(null, "Ban can nhap so vao R");
					return;
				}
				if (R <= 0) {
					JOptionPane.showMessageDialog(null, "Ban can nhap so duong vao R");
					return;
				}
				HinhTron l = new HinhTron(R);
				ql.themHinhTron(l);
				hienThiTable(ds);
			}
		});

		btnThem.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnThem.setBounds(335, 58, 106, 33);
		contentPane.add(btnThem);

		JButton btnXoa = new JButton("Xoa");
		btnXoa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int index = table.getSelectedRow();
				if (index < 0) {
					JOptionPane.showMessageDialog(null, "Chon hang de xoa");
					return;
				}
				int result = JOptionPane.showConfirmDialog(null, "Ban muon xoa khong ?", "Yes/No",
						JOptionPane.YES_NO_OPTION);
				if (result == JOptionPane.YES_OPTION) {
					ql.xoaHinhTron(index);
					hienThiTable(ds);
				}
			}
		});
		btnXoa.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnXoa.setBounds(451, 58, 106, 33);
		contentPane.add(btnXoa);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(27, 113, 533, 225);
		contentPane.add(scrollPane);

		table = new JTable();
		table.setFont(new Font("Tahoma", Font.PLAIN, 16));
		table.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "R", "Dien tich" }) {
			Class[] columnTypes = new Class[] { Double.class, Double.class };

			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}

			boolean[] columnEditables = new boolean[] { false, false };

			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}

		});
		scrollPane.setViewportView(table);
	}

	private void hienThiTable(ArrayList<HinhTron> ds) {
		DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
		tableModel.setRowCount(0);
//		for (int i = 0; i < ds.size(); i++) {
//			Object[] row = { ds.get(i).getR(), ds.get(i).getDientich() };
//			tableModel.addRow(row);
//		}
		for (HinhTron hinhTron : ds) {
			Object[] row = { hinhTron.getR(), hinhTron.getDientich() };
			tableModel.addRow(row);
		}
	}
}