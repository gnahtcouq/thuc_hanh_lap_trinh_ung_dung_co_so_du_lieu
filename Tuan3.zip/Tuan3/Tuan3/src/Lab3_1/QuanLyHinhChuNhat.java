package Lab3_1;

import java.util.ArrayList;

public class QuanLyHinhChuNhat {
	private ArrayList<HinhChuNhat> ds = new ArrayList<HinhChuNhat>();

	public ArrayList<HinhChuNhat> getDs() {
		return ds;
	}

	public void setDs(ArrayList<HinhChuNhat> ds) {
		this.ds = ds;
	}

	public void themHinhChuNhat(HinhChuNhat hinhChuNhat) {
		ds.add(hinhChuNhat);
	}

	public void xoaHinhChuNhat(int index) {
		if (index >= 0 && index < ds.size())
			ds.remove(index);
	}

	public QuanLyHinhChuNhat(ArrayList<HinhChuNhat> ds) {
//		super();
		this.ds = ds;
	}

	public QuanLyHinhChuNhat() {
//		super();
		// TODO Auto-generated constructor stub
	}

}
