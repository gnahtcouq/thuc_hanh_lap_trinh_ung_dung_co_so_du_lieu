package Lab3_1;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;

public class bt5 extends JFrame {
	private DefaultListModel<HinhChuNhat> model = new DefaultListModel<>();
	private JPanel contentPane;
	private JTextField txtChieuDai;
	private JTextField txtChieuRong;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					bt5 frame = new bt5();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public bt5() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 548, 383);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblChieuDai = new JLabel("Chieu dai");
		lblChieuDai.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblChieuDai.setBounds(10, 10, 93, 33);
		contentPane.add(lblChieuDai);

		JLabel lblChieuRong = new JLabel("Chieu rong");
		lblChieuRong.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblChieuRong.setBounds(10, 53, 93, 33);
		contentPane.add(lblChieuRong);

		txtChieuDai = new JTextField();
		txtChieuDai.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtChieuDai.setBounds(122, 10, 402, 28);
		contentPane.add(txtChieuDai);
		txtChieuDai.setColumns(10);

		txtChieuRong = new JTextField();
		txtChieuRong.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtChieuRong.setColumns(10);
		txtChieuRong.setBounds(122, 53, 402, 28);
		contentPane.add(txtChieuRong);

		JList list = new JList();

		JButton btnThem = new JButton("Them");
		btnThem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnThemActionPerformed(e);
			}
		});
		btnThem.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnThem.setBounds(308, 96, 103, 33);
		contentPane.add(btnThem);

		JButton btnXoa = new JButton("Xoa");
		btnXoa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int selectedIndex = list.getSelectedIndex();
				if (selectedIndex != -1) {
					DefaultListModel model = (DefaultListModel) list.getModel();
					model.remove(selectedIndex);
				}
			}
		});
		btnXoa.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnXoa.setBounds(421, 96, 103, 33);
		contentPane.add(btnXoa);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 149, 514, 187);
		contentPane.add(scrollPane);

		list.setFont(new Font("Tahoma", Font.PLAIN, 16));
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		list.setModel(model);
		scrollPane.setViewportView(list);
	}

	private void btnThemActionPerformed(ActionEvent e) {
		double cd = Double.parseDouble(txtChieuDai.getText());
		double cr = Double.parseDouble(txtChieuRong.getText());
		HinhChuNhat hcn = new HinhChuNhat(cd, cr);
		model.addElement(hcn);
	}
}
