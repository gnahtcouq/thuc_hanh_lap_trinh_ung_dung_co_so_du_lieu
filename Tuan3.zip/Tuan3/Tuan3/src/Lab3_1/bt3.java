package Lab3_1;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class bt3 extends JFrame {

	private JPanel contentPane;
	private JTextField txtA;
	private JTextField txtB;
	private JTextField txtKq;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					bt3 frame = new bt3();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public bt3() {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 197);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("So A:");
		lblNewLabel.setBounds(10, 24, 46, 14);
		contentPane.add(lblNewLabel);

		JLabel lblSoB = new JLabel("So B:");
		lblSoB.setBounds(10, 49, 46, 14);
		contentPane.add(lblSoB);

		JLabel lblPhepTinh = new JLabel("Phep tinh:");
		lblPhepTinh.setBounds(10, 74, 56, 14);
		contentPane.add(lblPhepTinh);

		JLabel lblKetQua = new JLabel("Ket qua:");
		lblKetQua.setBounds(10, 130, 46, 14);
		contentPane.add(lblKetQua);

		txtA = new JTextField();
		txtA.setBounds(76, 21, 348, 20);
		contentPane.add(txtA);
		txtA.setColumns(10);

		txtB = new JTextField();
		txtB.setColumns(10);
		txtB.setBounds(76, 46, 348, 20);
		contentPane.add(txtB);

		txtKq = new JTextField();
		txtKq.setColumns(10);
		txtKq.setBounds(76, 127, 348, 20);
		contentPane.add(txtKq);

		JComboBox cboPhepTinh = new JComboBox();
		cboPhepTinh.setBounds(76, 71, 238, 20);
		contentPane.add(cboPhepTinh);

		JButton btnKq = new JButton("Ket qua");
		btnKq.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tinh();
			}

			private void tinh() {
				double a, b, kq = 0;
				a = Double.parseDouble(txtA.getText());
				b = Double.parseDouble(txtB.getText());
				int selected = cboPhepTinh.getSelectedIndex();
				switch (selected) {
				case 0:
					kq = a + b;
					break;
				case 1:
					kq = a - b;
					break;
				case 2:
					kq = a * b;
					break;
				case 3:
					kq = a / b;
					break;
				}
				txtKq.setText(kq + "");
			}
		});
		btnKq.setBounds(335, 70, 89, 23);
		contentPane.add(btnKq);
		cboPhepTinh.addItem("+");
		cboPhepTinh.addItem("-");
		cboPhepTinh.addItem("*");
		cboPhepTinh.addItem("/");
	}
}
