package Lab3_1;

public class HinhTron {
	private double r;

	public HinhTron() {
	}

	public HinhTron(double r) {
		this.r = r;
	}

	public double getR() {
		return r;
	}

	public void setR(double r) {
		this.r = r;
	}

	public double getDientich() {
		return Math.PI * r * r;
	}

	public double getChuvi() {
		return 2 * Math.PI * r;
	}

	@Override
	public String toString() {
		return "R=" + r + "; DT=" + getDientich() + "; CV=" + getChuvi();
	}

}
