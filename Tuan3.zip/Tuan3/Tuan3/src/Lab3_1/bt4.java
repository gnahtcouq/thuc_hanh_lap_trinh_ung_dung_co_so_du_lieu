package Lab3_1;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class bt4 extends JFrame {

	private JPanel contentPane;
	private JTextField txtSoTien;
	private JTextField txtVND;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					bt4 frame = new bt4();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public bt4() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 186);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblSoTien = new JLabel("So tien:");
		lblSoTien.setBounds(10, 24, 46, 14);
		contentPane.add(lblSoTien);

		JLabel lblDonVi = new JLabel("Don vi:");
		lblDonVi.setBounds(10, 76, 46, 14);
		contentPane.add(lblDonVi);

		JLabel lblVND = new JLabel("VND =");
		lblVND.setBounds(10, 106, 46, 14);
		contentPane.add(lblVND);

		txtSoTien = new JTextField();
		txtSoTien.setBounds(84, 21, 340, 20);
		contentPane.add(txtSoTien);
		txtSoTien.setColumns(10);

		JComboBox cboDonVi = new JComboBox();
		cboDonVi.setBounds(84, 73, 241, 20);
		contentPane.add(cboDonVi);

		cboDonVi.addItem("USD");
		cboDonVi.addItem("EURO");
		cboDonVi.addItem("JPY");

		JButton btnNewButton = new JButton("Doi tien");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tinh();
			}
			private void tinh() {
		        double a = Double.parseDouble(txtSoTien.getText());
		        double kq = 0;
				int selected = cboDonVi.getSelectedIndex();
				switch (selected) {
				case 0:
					kq = a * 23500;
					break;
				case 1:
					kq = a * 25585;
					break;
				case 2:
					kq = a * 177.6;
					break;
				}
				txtVND.setText(kq + "");
			}
		});
		btnNewButton.setBounds(335, 72, 89, 23);
		contentPane.add(btnNewButton);

		txtVND = new JTextField();
		txtVND.setBounds(84, 103, 340, 20);
		contentPane.add(txtVND);
		txtVND.setColumns(10);
	}
}
