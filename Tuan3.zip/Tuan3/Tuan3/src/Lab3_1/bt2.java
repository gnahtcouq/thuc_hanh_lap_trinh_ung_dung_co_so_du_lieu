package Lab3_1;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.ButtonGroup;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class bt2 extends JFrame {

	private JPanel contentPane;
	private JTextField txtSoTien;
	private JTextField txtVND;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					bt2 frame = new bt2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public bt2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 170);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Nhap so tien:");
		lblNewLabel.setBounds(10, 26, 73, 14);
		contentPane.add(lblNewLabel);
		
		txtSoTien = new JTextField();
		txtSoTien.setBounds(93, 23, 331, 20);
		contentPane.add(txtSoTien);
		txtSoTien.setColumns(10);
		
		JRadioButton rdbtnUSD = new JRadioButton("USD");
		buttonGroup.add(rdbtnUSD);
		rdbtnUSD.setBounds(93, 54, 52, 23);
		contentPane.add(rdbtnUSD);
		
		JRadioButton rdbtnEuro = new JRadioButton("EURO");
		buttonGroup.add(rdbtnEuro);
		rdbtnEuro.setBounds(163, 54, 53, 23);
		contentPane.add(rdbtnEuro);
		
		JRadioButton rdbtnJPY = new JRadioButton("JPY");
		buttonGroup.add(rdbtnJPY);
		rdbtnJPY.setBounds(233, 54, 53, 23);
		contentPane.add(rdbtnJPY);
		
		JButton btnNewButton = new JButton("Doi tien");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doiTien();
			}
		    private void doiTien() {
		        double a = Double.parseDouble(txtSoTien.getText());
		        double kq = 0;
		        
		        if (rdbtnUSD.isSelected())
		            kq = a * 23500;
		        else if (rdbtnEuro.isSelected())
		        	kq = a * 25585;
		        else if (rdbtnJPY.isSelected())
		        	kq = a * 177.6;
		        txtVND.setText(kq + "");
		    }
		});
		
		btnNewButton.setBounds(335, 54, 89, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("VND = ");
		lblNewLabel_1.setBounds(10, 91, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		txtVND = new JTextField();
		txtVND.setBounds(93, 88, 331, 20);
		contentPane.add(txtVND);
		txtVND.setColumns(10);
	}
}
