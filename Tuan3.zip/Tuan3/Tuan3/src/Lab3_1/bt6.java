package Lab3_1;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class bt6 extends JFrame {
	private JPanel contentPane;
	private JTextField txtChieuDai;
	private JTextField txtChieuRong;
	private JTable table;
	private QuanLyHinhChuNhat ql;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					bt6 frame = new bt6();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public bt6() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblChieuDai = new JLabel("Dai =");
		lblChieuDai.setBounds(10, 15, 74, 20);
		contentPane.add(lblChieuDai);

		JLabel lblChieuRong = new JLabel("Rong =");
		lblChieuRong.setBounds(10, 50, 74, 20);
		contentPane.add(lblChieuRong);

		txtChieuDai = new JTextField();
		txtChieuDai.setBounds(68, 16, 356, 20);
		contentPane.add(txtChieuDai);
		txtChieuDai.setColumns(10);

		txtChieuRong = new JTextField();
		txtChieuRong.setColumns(10);
		txtChieuRong.setBounds(68, 51, 356, 20);
		contentPane.add(txtChieuRong);

		ql = new QuanLyHinhChuNhat();
		ArrayList<HinhChuNhat> ds = ql.getDs();

		JButton btnThem = new JButton("Them");
		btnThem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String chieuDai = txtChieuDai.getText().trim();
				String chieuRong = txtChieuRong.getText().trim();

				double ChieuDai = 0, ChieuRong = 0;

				if (chieuDai.isEmpty() || chieuRong.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Ban can nhap chieu dai va chieu rong");
					return;
				}
				try {
					ChieuDai = Double.parseDouble(chieuDai);
					ChieuRong = Double.parseDouble(chieuRong);
				} catch (NumberFormatException ex) {
					JOptionPane.showMessageDialog(null, "Ban can nhap so vao chieu dai va chieu rong");
					return;
				}
				if (ChieuDai <= 0 || ChieuRong <= 0) {
					JOptionPane.showMessageDialog(null, "Ban can nhap so duong vao chieu dai va chieu rong");
					return;
				}
				HinhChuNhat hcn = new HinhChuNhat(ChieuDai, ChieuRong);
				ql.themHinhChuNhat(hcn);
				hienThiTable(ds);
			}
		});
		btnThem.setBounds(188, 83, 107, 29);
		contentPane.add(btnThem);

		JButton btnXoa = new JButton("Xoa");
		btnXoa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int index = table.getSelectedRow();
				if (index < 0) {
					JOptionPane.showMessageDialog(null, "Chon hang de xoa");
					return;
				}
				int result = JOptionPane.showConfirmDialog(null, "Ban muon xoa khong ?", "Yes/No",
						JOptionPane.YES_NO_OPTION);
				if (result == JOptionPane.YES_OPTION) {
					ql.xoaHinhChuNhat(index);
					hienThiTable(ds);
				}
			}
		});
		btnXoa.setBounds(317, 83, 107, 29);
		contentPane.add(btnXoa);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 122, 414, 129);
		contentPane.add(scrollPane);

		table = new JTable();
		table.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Dai", "Rong", "DT", "CV" }) {
			Class[] columnTypes = new Class[] { Double.class, Double.class, Double.class, Double.class };

			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}

			boolean[] columnEditables = new boolean[] { false, false, false, false };

			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setViewportView(table);
	}

	private void hienThiTable(ArrayList<HinhChuNhat> ds) {
		DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
		tableModel.setRowCount(0);
		for (HinhChuNhat hinhChuNhat : ds) {
			Object[] row = { hinhChuNhat.getChieuDai(), hinhChuNhat.getChieuRong(), hinhChuNhat.getDienTich(),
					hinhChuNhat.getChuVi() };
			tableModel.addRow(row);
		}
	}
}
