package Lab3_1;

public class HinhChuNhat {
	private double chieuDai;
	private double chieuRong;

	public double getChieuDai() {
		return chieuDai;
	}

	public void setChieuDai(double chieuDai) {
		this.chieuDai = chieuDai;
	}

	public double getChieuRong() {
		return chieuRong;
	}

	public void setChieuRong(double chieuRong) {
		this.chieuRong = chieuRong;
	}

	public HinhChuNhat(double chieuDai, double chieuRong) {
		this.chieuDai = chieuDai;
		this.chieuRong = chieuRong;
	}

	public HinhChuNhat() {
		// TODO Auto-generated constructor stub
	}

	public double getDienTich() {
		return chieuDai * chieuRong;
	}

	public double getChuVi() {
		return 2 * (chieuDai + chieuRong);
	}

	@Override
	public String toString() {
		return "Dai=" + chieuDai + ", Rong=" + chieuRong + ", DT=" + getDienTich() + ", CV=" + getChuVi();
	}

}
