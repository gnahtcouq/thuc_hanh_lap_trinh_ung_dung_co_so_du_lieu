package main;

import org.hibernate.Session;
import org.hibernate.Transaction;

import model.Lop;
import util.HibernateUtil;

public class bt3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session = HibernateUtil.openSession();
		Transaction tx = session.beginTransaction();

		try {
			Lop lop1 = new Lop(6, "QTKD", null);
			Lop lop2 = new Lop(8, "CNTP", null);
			Lop lop3 = new Lop(9, "KTXD", null);

			session.save(lop1);
			session.save(lop2);
			session.save(lop3);

			tx.commit();
			session.close();
		} catch (Exception e) {
			// Rollback giao dịch nếu có lỗi xảy ra
			if (tx != null) {
				tx.rollback();
			}
			e.printStackTrace();
		} finally {
			// Đóng session
			HibernateUtil.close();
		}
	}

}
