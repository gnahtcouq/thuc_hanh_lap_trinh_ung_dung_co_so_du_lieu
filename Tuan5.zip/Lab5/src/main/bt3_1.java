package main;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import model.Lop;
import util.HibernateUtil;

public class bt3_1 {

	public static void main(String[] args) {
		Session session = HibernateUtil.openSession();
		Transaction tx = session.beginTransaction();

		Scanner input = new Scanner(System.in);
		System.out.print("Nhap ma lop: ");
		int malop = input.nextInt();

		try {
			Lop lop = (Lop) session.get(Lop.class, malop);
			if (lop != null) {
				session.delete(lop);
				System.out.println("Da xoa lop " + malop);
			} else {
				System.out.println("Khong tim thay lop co ma la " + malop);
			}
			tx.commit();
			session.close();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
			e.printStackTrace();
		} finally {
			HibernateUtil.close();
		}
	}

}
