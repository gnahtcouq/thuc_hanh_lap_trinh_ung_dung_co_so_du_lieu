package main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import model.Lop;
import util.HibernateUtil;

public class LopFrm extends JFrame {
	private final DefaultTableModel model = new DefaultTableModel(new Object[] { "MA LOP", "TEN LOP" }, 0);

	public LopFrm() {
		initComponents();
		loadData();
		setLocationRelativeTo(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosed(java.awt.event.WindowEvent evt) {
				HibernateUtil.getSessionFactory().close();
			}
		});
	}

	private void loadData() {
		Session ses = HibernateUtil.getSessionFactory().openSession();
		ses.beginTransaction();
		List<Lop> dslop = ses.createQuery("from Lop").list();
		for (Lop lop : dslop) {
			Object[] row = { lop.getMalop(), lop.getTenlop() };
			model.addRow(row);
		}
		ses.getTransaction().commit();

	}

	@SuppressWarnings("unchecked")

	private void initComponents() {

		jLabel1 = new javax.swing.JLabel();
		jLabel2 = new javax.swing.JLabel();
		txtMalop = new javax.swing.JTextField();
		jLabel3 = new javax.swing.JLabel();
		txtTenlop = new javax.swing.JTextField();
		btnThem = new javax.swing.JButton();
		btnThem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String maLop = txtMalop.getText();
				String tenLop = txtTenlop.getText();
				// Kiểm tra trùng mã lớp
				Session session = HibernateUtil.getSessionFactory().openSession();
				Criteria criteria = session.createCriteria(Lop.class);
				criteria.add(Restrictions.eq("malop", Integer.parseInt(maLop)));
				List<Lop> lopList = criteria.list();
				if (!lopList.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Mã lớp đã tồn tại trong CSDL");
					return;
				}
				// Thêm lớp vào CSDL
				Lop lop = new Lop(Integer.parseInt(maLop), tenLop, null);
				session.beginTransaction();
				session.save(lop);
				Object[] row = { lop.getMalop(), lop.getTenlop() };
				model.addRow(row);
				session.getTransaction().commit();
				HibernateUtil.getSessionFactory().close();
				// Thông báo thêm thành công
				JOptionPane.showMessageDialog(null, "Thêm lớp thành công");
			}
		});

		btnSua = new javax.swing.JButton();
		btnSua.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int selectedRow = tblLop.getSelectedRow();
				if (selectedRow == -1) {
					JOptionPane.showMessageDialog(null, "Vui lòng chọn một lớp để sửa!", "Thông báo",
							JOptionPane.WARNING_MESSAGE);
					return;
				}
				String tenLop = txtTenlop.getText();
				if (tenLop.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Vui lòng nhập tên lớp!", "Thông báo",
							JOptionPane.WARNING_MESSAGE);
					return;
				}

				int maLop = (int) tblLop.getValueAt(selectedRow, 0);

				Session session = HibernateUtil.getSessionFactory().openSession();
				session.beginTransaction();

				Lop lop = (Lop) session.get(Lop.class, maLop);

				lop.setTenlop(tenLop);
				session.update(lop);
				session.getTransaction().commit();
				model.setValueAt(tenLop, selectedRow, 1);
				JOptionPane.showMessageDialog(null, "Sửa thông tin lớp thành công!", "Thông báo",
						JOptionPane.INFORMATION_MESSAGE);
				HibernateUtil.getSessionFactory().close();

			}
		});
		btnXoa = new javax.swing.JButton();
		btnXoa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int selectedRowIndex = tblLop.getSelectedRow();
				if (selectedRowIndex >= 0) {
					int malop = (int) tblLop.getModel().getValueAt(selectedRowIndex, 0);
					Session session = HibernateUtil.getSessionFactory().openSession();
					session.beginTransaction();
					Lop lop = (Lop) session.get(Lop.class, malop);
					session.delete(lop);
					session.getTransaction().commit();
					session.close();
					model.removeRow(selectedRowIndex);
					JOptionPane.showMessageDialog(null, "Xóa thành công!");
				} else {
					JOptionPane.showMessageDialog(null, "Vui lòng chọn lớp cần xóa!");
				}
			}
		});
		jScrollPane1 = new javax.swing.JScrollPane();
		tblLop = new javax.swing.JTable();

		jLabel1.setText("jLabel1");

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jLabel2.setText("Ma lop:");

		jLabel3.setText("Ten lop:");

		btnThem.setText("Them");

		btnSua.setText("Sua");

		btnXoa.setText("Xoa");

		tblLop.setModel(model);
		jScrollPane1.setViewportView(tblLop);

		tblLop.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent event) {
				if (!event.getValueIsAdjusting()) {
					int selectedRow = tblLop.getSelectedRow();
					if (selectedRow != -1) {
						int maLop = (int) tblLop.getValueAt(selectedRow, 0);
						String tenLop = (String) tblLop.getValueAt(selectedRow, 1);
						txtMalop.setText(String.valueOf(maLop));
						txtTenlop.setText(tenLop);
					}
				}
			}
		});

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup().addContainerGap()
						.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
								.addGroup(layout.createSequentialGroup().addComponent(jLabel2)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(txtMalop))
								.addGroup(layout.createSequentialGroup().addComponent(jLabel3)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(txtTenlop))
								.addGroup(layout.createSequentialGroup().addComponent(btnThem).addGap(18, 18, 18)
										.addComponent(btnSua).addGap(18, 18, 18).addComponent(btnXoa)
										.addGap(0, 165, Short.MAX_VALUE)))
						.addContainerGap()));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup().addContainerGap()
						.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(jLabel2).addComponent(txtMalop, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
						.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(jLabel3).addComponent(txtTenlop, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
						.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(btnThem).addComponent(btnSua).addComponent(btnXoa))
						.addGap(18, 18, 18)
						.addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE)
						.addContainerGap()));

		pack();
	}// </editor-fold>//GEN-END:initComponents

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		/* Set the Nimbus look and feel */
		// <editor-fold defaultstate="collapsed" desc=" Look and feel setting code
		// (optional) ">
		/*
		 * If Nimbus (introduced in Java SE 6) is not available, stay with the default
		 * look and feel. For details see
		 * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
		 */
		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(LopFrm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(LopFrm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(LopFrm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(LopFrm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		}
		// </editor-fold>

		/* Create and display the form */
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new LopFrm().setVisible(true);
			}
		});

	}

	// Variables declaration - do not modify//GEN-BEGIN:variables
	private javax.swing.JButton btnThem;
	private javax.swing.JButton btnSua;
	private javax.swing.JButton btnXoa;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JTable tblLop;
	private javax.swing.JTextField txtMalop;
	private javax.swing.JTextField txtTenlop;
	// End of variables declaration//GEN-END:variables
}
