package main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import model.Lop;
import util.HibernateUtil;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();

//		Lop lop1 = new Lop();
//		lop1.setMalop(6);
//		lop1.setTenlop("CNTT");

		Lop lop2 = new Lop();
		lop2.setMalop(7);
		lop2.setTenlop("CNTP");
//
//		Transaction t = session.beginTransaction();
//		session.save(lop1);
//		t.commit();

		Lop lop1 = (Lop) session.get(Lop.class, 6);
		System.out.println(lop1.toString());

		Transaction t = session.beginTransaction();
		session.delete(lop1);
		session.save(lop2);
		t.commit();

		session.close();
//		factory.close();
	}

}
