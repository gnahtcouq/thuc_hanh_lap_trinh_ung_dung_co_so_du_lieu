package main;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import model.Lop;
import model.Sinhvien;
import util.HibernateUtil;

public class bt4 {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = session.beginTransaction();
		Scanner scanner = new Scanner(System.in);

		try {
			System.out.print("Nhap ho ten sinh vien: ");
			String hoten = scanner.nextLine();

			System.out.print("Nhap diem trung binh: ");
			double dtb = scanner.nextDouble();
			scanner.nextLine();

			System.out.print("Nhap ma lop: ");
			int maLop = scanner.nextInt();
			scanner.nextLine();

			// Tìm kiếm đối tượng Lop theo mã lớp được nhập từ bàn phím
			Lop lop = (Lop) session.get(Lop.class, maLop);
			if (lop == null) {
				System.out.println("Khong tim thay lop co ma " + maLop);
				return;
			}

			// Tạo đối tượng Sinhvien mới với thông tin từ bàn phím
			Sinhvien sv = new Sinhvien();
			sv.setHoten(hoten);
			sv.setDtb(dtb);
			sv.setLop(lop);
			session.save(sv);

			System.out.println("Da them moi sinh vien " + hoten + " vao lop " + lop.getTenlop());

			transaction.commit();
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
		} finally {
			session.close();
			scanner.close();
		}
	}

}
