package main;

import org.hibernate.Session;

import model.Lop;
import model.Sinhvien;
import util.HibernateUtil;

public class Lab5_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session ses = HibernateUtil.openSession();
		ses.beginTransaction();
		Lop lop = (Lop) ses.get(Lop.class, 3);
		if (lop != null) {
			Sinhvien sv = new Sinhvien();
			sv.setHoten("Lai Van Toan");
			sv.setDtb(9.5);
			sv.setLop(lop);
			ses.save(sv);
			System.out.println("Them thanh cong!");
			System.out.println(sv);
		} else
			System.out.println("Khong tim thay lop!");
		ses.getTransaction().commit();
		HibernateUtil.close();
	}

}
