package util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class HibernateUtil {
	private static SessionFactory factory;
	static {
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");

		ServiceRegistry registry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties())
				.build();
		factory = configuration.buildSessionFactory(registry);
	}

	public static SessionFactory getSessionFactory() {
		return factory;
	}

	public static Session openSession() {
		return factory.openSession();
	}

	public static void close() {
		factory.close();
	}
}
